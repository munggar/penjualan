<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Manajemen Produk - Toko Jahit</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="app.css" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr" crossorigin="anonymous">
</head>
<body>
  <header>
    <h1>Toko Aksesoris Jahit</h1>
    <nav>
      <a href="/">Dashboard</a>
      <a href="/produk">Produk</a>
      <a href="/transaksi">Transaksi</a>
      <a href="/laporan">Laporan</a>
    </nav>
  </header>

  <div class="container">
    <div class="card">
      <h2>Tambah Produk</h2>
      <?php if(session('success')): ?>
        <div class="alert-success"><?php echo e(session('success')); ?></div>
      <?php endif; ?>
      <form method="POST" action="<?php echo e(route('produk.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
          <label>Nama Produk</label>
          <input type="text" name="name" required />
        </div>
        <div class="form-group">
          <label>Harga Beli</label>
          <input type="number" name="purchase_price" required />
        </div>
        <div class="form-group">
          <label>Harga Jual</label>
          <input type="number" name="sale_price" required />
        </div>
        <div class="form-group">
          <label>Stok/Jumlah</label>
          <input type="number" name="stock" required />
        </div>
        <button class="btn" type="submit">Simpan</button>
      </form>
    </div>

    <div class="card">
      <h2>Daftar Produk</h2>
      <table>
        <thead>
          <tr>
            <th>Nama</th>
            <th>Harga Beli</th>
            <th>Harga Jual</th>
            <th>Stok</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($product->name); ?></td>
              <td>Rp<?php echo e(number_format($product->purchase_price, 0, ',', '.')); ?></td>
              <td>Rp<?php echo e(number_format($product->sale_price, 0, ',', '.')); ?></td>
              <td><?php echo e($product->stock); ?></td>
              <td>
  <div class="d-flex gap-2">
    <form action="<?php echo e(route('produk.destroy', $product->id)); ?>" method="POST" onsubmit="return confirm('Yakin hapus?')">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <button class="btn btn-danger btn-sm" type="submit">Hapus</button>
    </form>
    <a href="<?php echo e(route('produk.edit', $product->id)); ?>" class="btn btn-secondary btn-sm">Edit</a>
    <a href="<?php echo e(route('produk.tambah', $product->id)); ?>" class="btn btn-secondary btn-sm">Tambah Stok</a>
  </div>
</td>

            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php if($products->isEmpty()): ?>
            <tr><td colspan="5">Belum ada produk.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>
<?php /**PATH C:\xampp1\htdocs\penjualan\resources\views\produk\produk.blade.php ENDPATH**/ ?>