<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Transaksi - Toko Jahit</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="css/transaksi.css">
</head>
<body>
  <header>
    <h1>Toko Aksesoris Jahit</h1>
    <nav>
      <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
      <a href="<?php echo e(route('produk.index')); ?>">Produk</a>
      <a href="<?php echo e(route('transaksi.index')); ?>">Transaksi</a>
      <a href="#">Laporan</a>
    </nav>
  </header>

  <div class="container">
    <div class="card">
      <h2>Transaksi Penjualan</h2>
      <form method="POST" action="<?php echo e(route('transaksi.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
          <label for="produk_id">Pilih Produk</label>
          <select name="produk_id" id="produk_id">
            <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_produk); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="form-group">
          <label for="jumlah">Jumlah</label>
          <input type="number" name="jumlah" id="jumlah" min="1" required />
        </div>
        <div class="form-group">
          <label for="diskon">Diskon (opsional)</label>
          <input type="number" name="diskon" id="diskon" min="0" />
        </div>
        <button class="btn" type="submit">Proses Transaksi</button>
      </form>
    </div>

    <div class="card">
      <h2>Riwayat Transaksi</h2>
      <table>
        <thead>
          <tr>
            <th>Tanggal</th>
            <th>Produk</th>
            <th>Jumlah</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($transaksi->created_at->format('d-m-Y')); ?></td>
            <td><?php echo e($transaksi->produk->nama_produk); ?></td>
            <td><?php echo e($transaksi->jumlah); ?></td>
            <td>Rp<?php echo e(number_format($transaksi->total, 0, ',', '.')); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>
<?php /**PATH C:\xampp1\htdocs\penjualan\resources\views\transaksi.blade.php ENDPATH**/ ?>