<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Transaksi</h1>

    <a href="<?php echo e(route('transaksi.create')); ?>" class="btn btn-primary mb-3">Tambah Transaksi</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Nama Pelanggan</th>
                <th>Total</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($transaksi->transaction_date); ?></td>
                    <td><?php echo e($transaksi->customer_name); ?></td>
                    <td>Rp<?php echo e(number_format($transaksi->total_amount, 0, ',', '.')); ?></td>
                    <td>
                        <a href="<?php echo e(route('transaksi.show', $transaksi->id)); ?>" class="btn btn-sm btn-info">Detail</a>
                        <form action="transaksi/destroy/$transaksi->id" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin menghapus transaksi ini?')">Hapus</button>
                        </form>
                    </td>
                    <td>
            <a href="<?php echo e(route('transaksi.cetak', $transaksi->id)); ?>" class="btn btn-print" target="_blank">Cetak Nota</a>
        </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\penjualan\resources\views\transaksi\index.blade.php ENDPATH**/ ?>