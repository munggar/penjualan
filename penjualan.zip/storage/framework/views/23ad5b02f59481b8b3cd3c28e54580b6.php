<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Edit Produk</title>
  <link rel="stylesheet" href="/app.css" />
</head>
<body>
  <div class="container">
    <div class="card">
      <h2>Tambah Stok</h2>
      
      <form action="<?php echo e(route('produk.updateStok', $product->id)); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <?php echo method_field('PUT'); ?>
  <input type="number" name="stock" placeholder="Jumlah stok tambahan" required>
  <button type="submit" class="btn btn-primary">Tambah Stok</button>
</form>

    </div>
  </div>
</body>
</html>
<?php /**PATH C:\xampp1\htdocs\penjualan\resources\views\produk\tambah.blade.php ENDPATH**/ ?>