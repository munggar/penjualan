<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: Arial, sans-serif; font-size: 12px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #000; padding: 5px; text-align: left; }
        .no-border td { border: none; }
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .lunas { font-size: 24px; font-weight: bold; color: green; margin-top: 20px; text-align: center; }
    </style>
</head>
<body>

    <table class="no-border">
        <tr>
            <td>Bandung,</td>
            <td><?php echo e(\Carbon\Carbon::parse($transaksi->transaction_date)->format('d / m / Y')); ?></td>
        </tr>
        <tr>
            <td>Tuan :</td>
            <td><?php echo e($transaksi->customer_name); ?></td>
        </tr>
        <tr>
            <td></td>
            <td>Di <?php echo e($transaksi->alamat ?? '_________'); ?></td>
        </tr>
    </table>

    <br>

    <strong>Nota No:</strong> <?php echo e($transaksi->id); ?>


    <table>
        <thead>
            <tr>
                <th>NAMA BARANG</th>
                <th>BANYAKNYA</th>
                <th>HARGA</th>
                <th>METODE PEMBAYARAN</th>
                <th>JUMLAH</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $transaksi->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($detail->produk->name ?? 'Produk Dihapus'); ?></td>
                <td><?php echo e($detail->quantity); ?> <?php echo e($detail->product->satuan ?? ''); ?></td>
                <td>Rp <?php echo e(number_format($detail->price, 0, ',', '.')); ?></td>
                <td><?php echo e($transaksi->payment_method === 'langsung' ? 'Bayar Langsung' : 'Cicilan'); ?></td>
                <td>Rp <?php echo e(number_format($detail->price * $detail->quantity, 0, ',', '.')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <td colspan="3" class="text-right"><strong>Jumlah Rp</strong></td>
                    <td><strong>Rp <?php echo e(number_format($transaksi->total_amount, 0, ',', '.')); ?></strong></td>
                </td>
            </tr>

            <?php
                $dibayar = $transaksi->pembayaranCicilan->sum('jumlah_bayar');
                $sisa = $transaksi->total_amount - $dibayar;
            ?>

            <tr>
                <td>
                    <td colspan="3" class="text-right"><strong>Total Dibayar</strong></td>
                    <td><strong>Rp <?php echo e(number_format($dibayar, 0, ',', '.')); ?></strong></td>
                </td>
            </tr>
            <tr>
                <td>
                    <td colspan="3" class="text-right"><strong>Sisa Tagihan</strong></td>
                    <td><strong>Rp <?php echo e(number_format($sisa, 0, ',', '.')); ?></strong></td>
                </td>
            </tr>
        </tbody>
    </table>

    <?php if($sisa <= 0): ?>
    <div class="lunas">✅ LUNAS</div>
    <?php endif; ?>

    <br><br>

    <table class="no-border">
        <tr>
            <td style="width: 50%;">Tanda terima</td>
            <td>Hormat Kami</td>
        </tr>
        <tr>
            <td style="height: 50px;"></td>
            <td></td>
        </tr>
        <tr>
            <td>.......................</td>
            <td>Wildan</td>
        </tr>
    </table>

</body>
</html>
<?php /**PATH C:\xampp1\htdocs\penjualan\resources\views\transaksi\nota_pdf.blade.php ENDPATH**/ ?>